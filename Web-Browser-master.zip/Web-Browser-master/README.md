# Web-Browser
A Web Browser Android Project that allows you to surf over internet along with action controls.
